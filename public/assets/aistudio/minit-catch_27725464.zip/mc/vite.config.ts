import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: { target: 'es2022', sourcemap: true }, // top-level await requires es2022+
  test: { environment: 'node', include: ['tests/**/*.test.ts'] },
});
