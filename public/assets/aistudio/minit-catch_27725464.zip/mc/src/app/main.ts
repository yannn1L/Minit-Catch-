import { Application, TextureStyle, type Ticker } from 'pixi.js';
import { LoadingScene } from '../presentation/scenes/LoadingScene.ts';
import { SceneManager } from '../presentation/scenes/SceneManager.ts';
import { PixelFont } from '../presentation/ui/PixelFont.ts';

// Pixel-perfect: nearest sampling everywhere, 1:1 device pixels (no resolution scaling), integer zoom in scenes.
TextureStyle.defaultOptions.scaleMode = 'nearest';

const dpr = (): number => window.devicePixelRatio || 1;
const physical = (): { w: number; h: number } => ({ w: Math.max(1, Math.floor(window.innerWidth * dpr())), h: Math.max(1, Math.floor(window.innerHeight * dpr())) });

/** WebGPU first, WebGL fallback (GDD gracefulDegrade). */
async function createApp(): Promise<Application> {
  const { w, h } = physical();
  let lastError: unknown;
  for (const preference of ['webgpu', 'webgl'] as const) {
    const app = new Application();
    try {
      await app.init({ preference, width: w, height: h, resolution: 1, autoDensity: false, antialias: false, background: 0x10131c, roundPixels: true });
      return app;
    } catch (e) {
      lastError = e;
      console.warn(`[minitcatch] ${preference} init failed, trying next backend`, e);
    }
  }
  throw new Error(`No usable renderer: ${String(lastError)}`);
}

const app = await createApp();
document.body.appendChild(app.canvas);
const font = new PixelFont();
const scenes = new SceneManager(app.stage);

function fit(): void {
  const { w, h } = physical();
  app.renderer.resize(w, h);
  app.canvas.style.width = `${window.innerWidth}px`;
  app.canvas.style.height = `${window.innerHeight}px`;
  scenes.resize(w, h);
}
window.addEventListener('resize', fit);
app.ticker.add((t: Ticker) => scenes.update(t.deltaMS / 1000));
fit();
scenes.goto(new LoadingScene({ app, font, scenes }));
