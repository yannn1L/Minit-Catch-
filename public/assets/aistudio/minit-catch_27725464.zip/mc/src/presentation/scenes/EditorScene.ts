import { Container, Sprite } from 'pixi.js';
import type { GameContext } from '../../app/GameContext.ts';
import { arenaId, type RoasterId } from '../../core/ids.ts';
import { mulberry32 } from '../../core/rng.ts';
import { SLOT_COLORS, UI } from '../../data/palette.ts';
import { defaultChickenSpawn, MAX_PARTICIPANTS, MIN_PARTICIPANTS } from '../../domain/rules/constants.ts';
import { validateMatchConfig } from '../../domain/rules/validation.ts';
import { buildPreview } from '../render/ArenaRenderer.ts';
import { virtualFor } from '../ui/layout.ts';
import { Button, Slider, label, rect } from '../ui/widgets.ts';
import type { Scene } from './Scene.ts';
import { SimulationScene } from './SimulationScene.ts';

const PRESETS = [2, 4, 7, 9] as const;
const SPEEDS = [0.5, 1, 2, 4] as const;

function randomSeed32(): number {
  const a = new Uint32Array(1);
  crypto.getRandomValues(a);
  return a[0]! === 0 ? 1 : a[0]!;
}

/** Pure-Pixi editor. EditorState is one mutable object (ctx.config + the few transient fields below). */
export class EditorScene implements Scene {
  readonly root = new Container();
  private readonly ctx: GameContext;
  private readonly content = new Container();
  private seedText: string;
  private seedFocus = false;
  private error = '';
  private w = 1;
  private h = 1;

  constructor(ctx: GameContext) {
    this.ctx = ctx;
    this.seedText = String(ctx.config.seed);
    this.root.addChild(this.content);
  }

  enter(): void {
    this.ctx.audio.startBgm();
    this.ctx.audio.setDucked(false);
    this.build();
  }

  exit(): void {}
  update(): void {}

  resize(w: number, h: number): void {
    this.w = w;
    this.h = h;
    this.build();
  }

  private setParticipants(n: number): void {
    const cfg = this.ctx.config;
    const all = this.ctx.regs.roasters.ids();
    const ids: RoasterId[] = [];
    for (let i = 0; i < n; i++) ids.push(cfg.roasterIds[i] ?? all[i % all.length]!);
    cfg.participants = n;
    cfg.roasterIds = ids;
    cfg.chickenSpawn = defaultChickenSpawn(n);
    const arena = this.ctx.regs.arenas.get(cfg.arenaId);
    if (!arena.supports(n)) cfg.arenaId = this.ctx.regs.arenas.all().find((a) => a.supports(n))!.id;
    this.build();
  }

  private commitSeed(): void {
    const v = Number(this.seedText);
    this.ctx.config.seed = Number.isInteger(v) && v >= 1 && v <= 0xffffffff ? v : this.ctx.config.seed;
    this.seedText = String(this.ctx.config.seed);
    this.seedFocus = false;
    this.build();
  }

  private start(): void {
    if (this.seedFocus) this.commitSeed();
    const cfg = this.ctx.config;
    const errs = validateMatchConfig(cfg, this.ctx.regs);
    if (errs.length > 0) { this.error = errs[0]!; this.build(); return; }
    this.ctx.audio.play('go');
    this.ctx.scenes.goto(new SimulationScene(this.ctx, { ...cfg, roasterIds: [...cfg.roasterIds], chickenSpawn: { ...cfg.chickenSpawn }, observer: { ...cfg.observer } }));
  }

  private build(): void {
    for (const c of this.content.removeChildren()) c.destroy({ children: true });
    const { font, regs, audio } = this.ctx;
    const cfg = this.ctx.config;
    const v = virtualFor(this.w, this.h);
    this.content.scale.set(v.scale);
    this.content.position.set(v.ox, v.oy);
    this.content.addChild(rect(UI.bg, v.w, v.h));

    const wide = v.w >= 280;
    const colW = wide ? Math.floor(v.w / 2) - 8 : v.w - 12;
    const lx = 6;
    const rx = wide ? Math.floor(v.w / 2) + 2 : 6;
    let ly = 5;

    // ---- title + mute
    this.content.addChild(label(font, "MINIT CATCH!", lx, ly, UI.accent));
    const mute = new Button(font, audio.isMuted ? 'MUTED' : 'SOUND', v.w - 38, 3, 32, 11, () => { audio.toggleMute(); this.build(); });
    this.content.addChild(mute);
    ly += 14;

    // ---- participants
    this.content.addChild(label(font, `PARTICIPANTS ${cfg.participants}`, lx, ly, UI.dim));
    ly += 8;
    let bx = lx;
    for (const n of PRESETS) {
      this.content.addChild(new Button(font, String(n), bx, ly, 14, 11, () => this.setParticipants(n)).setSelected(cfg.participants === n));
      bx += 16;
    }
    this.content.addChild(new Button(font, '-', bx, ly, 11, 11, () => this.setParticipants(Math.max(MIN_PARTICIPANTS, cfg.participants - 1))));
    this.content.addChild(new Button(font, '+', bx + 13, ly, 11, 11, () => this.setParticipants(Math.min(MAX_PARTICIPANTS, cfg.participants + 1))));
    ly += 15;

    // ---- roster grid
    this.content.addChild(label(font, 'ROSTER (TAP TO CHANGE)', lx, ly, UI.dim));
    ly += 8;
    const cw = 37;
    const ch = 32;
    const cols = Math.max(1, Math.floor(colW / cw));
    const all = regs.roasters.ids();
    cfg.roasterIds.forEach((rid, i) => {
      const def = regs.roasters.get(rid);
      const cx = lx + (i % cols) * cw;
      const cy = ly + Math.floor(i / cols) * ch;
      const cell = new Container();
      cell.position.set(cx, cy);
      cell.addChild(rect(UI.border, cw - 2, ch - 2), rect(UI.panel, cw - 4, ch - 4, 1, 1), rect(SLOT_COLORS[i % SLOT_COLORS.length]!, cw - 4, 1, 1, 1));
      const icon = new Sprite(this.ctx.sprites.frame(def.sprite));
      icon.anchor.set(0.5, 0);
      icon.position.set(Math.floor((cw - 2) / 2), 4);
      cell.addChild(icon);
      cell.addChild(label(font, def.name.toUpperCase().slice(0, 6), Math.floor((cw - 2) / 2), 19, UI.text, 'center'));
      cell.addChild(label(font, this.abilityLabel(def.ability), Math.floor((cw - 2) / 2), 25, UI.dim, 'center'));
      cell.eventMode = 'static';
      cell.cursor = 'pointer';
      cell.on('pointertap', () => {
        cfg.roasterIds[i] = all[(all.indexOf(rid) + 1) % all.length]!;
        audio.play('ui');
        this.build();
      });
      this.content.addChild(cell);
    });
    ly += Math.ceil(cfg.participants / cols) * ch + 2;

    // ---- right column (or continues below on narrow screens)
    let ry = wide ? 19 : ly;
    this.content.addChild(label(font, 'ARENA', rx, ry, UI.dim));
    ry += 8;
    const arenas = regs.arenas.all();
    const cur = regs.arenas.get(cfg.arenaId);
    const idx = arenas.indexOf(cur);
    const pick = (d: number): void => {
      for (let k = 1; k <= arenas.length; k++) {
        const a = arenas[(idx + d * k + arenas.length * 4) % arenas.length]!;
        if (a.supports(cfg.participants)) { cfg.arenaId = arenaId(a.id); break; }
      }
      audio.play('ui');
      this.build();
    };
    this.content.addChild(new Button(font, '<', rx, ry + 14, 11, 11, () => pick(-1)));
    const prev = new Sprite(buildPreview(cur.build(cfg.participants, mulberry32(cfg.seed)), 40));
    prev.position.set(rx + 14, ry);
    this.content.addChild(prev);
    this.content.addChild(new Button(font, '>', rx + 57, ry + 14, 11, 11, () => pick(1)));
    this.content.addChild(label(font, cur.name.toUpperCase(), rx + 72, ry + 16, UI.text));
    ry += 44;

    // ---- chicken sliders
    const cs = cfg.chickenSpawn;
    const sw = Math.min(colW, 130);
    this.content.addChild(new Slider(font, 'CHICKENS START', rx, ry, sw, 0, 40, 1, cs.initial, (x) => String(x), (x) => { cs.initial = x; cs.cap = Math.max(cs.cap, x, 1); }));
    ry += 15;
    this.content.addChild(new Slider(font, 'CHICKEN CAP', rx, ry, sw, 1, 80, 1, cs.cap, (x) => String(x), (x) => { cs.cap = x; cs.initial = Math.min(cs.initial, x); }));
    ry += 15;
    this.content.addChild(new Slider(font, 'SPAWN EVERY', rx, ry, sw, 0.2, 3, 0.05, cs.interval, (x) => `${x.toFixed(2)}S`, (x) => { cs.interval = x; }));
    ry += 16;

    // ---- seed
    this.content.addChild(label(font, 'SEED', rx, ry, UI.dim));
    const seedBtn = new Button(font, this.seedText + (this.seedFocus ? '_' : ''), rx + 22, ry - 3, 62, 11, () => { this.seedFocus = true; this.build(); }).setSelected(this.seedFocus);
    this.content.addChild(seedBtn);
    this.content.addChild(new Button(font, 'RND', rx + 87, ry - 3, 22, 11, () => { cfg.seed = randomSeed32(); this.seedText = String(cfg.seed); this.seedFocus = false; this.build(); }));
    ry += 14;

    // ---- observer
    this.content.addChild(new Button(font, cfg.observer.cameraDirector ? 'DIRECTOR CAM: ON' : 'DIRECTOR CAM: OFF', rx, ry, 84, 11, () => { cfg.observer.cameraDirector = !cfg.observer.cameraDirector; this.build(); }).setSelected(cfg.observer.cameraDirector));
    ry += 14;
    let sx = rx;
    for (const s of SPEEDS) {
      this.content.addChild(new Button(font, `${s}X`, sx, ry, 20, 11, () => { cfg.observer.speed = s; this.build(); }).setSelected(cfg.observer.speed === s));
      sx += 22;
    }
    ry += 15;

    // ---- start
    const startY = wide ? Math.max(ry, v.h - 20) : Math.max(ry, ly) + 2;
    this.content.addChild(new Button(font, 'START MATCH', rx, startY, 90, 14, () => this.start()).setSelected(true));
    if (this.error !== '') this.content.addChild(label(font, this.error.toUpperCase().slice(0, 44), 6, v.h - 8, UI.bad));
  }

  private abilityLabel(id: string): string {
    return id.slice(0, 6).toUpperCase();
  }

  onKey(e: KeyboardEvent, down: boolean): void {
    if (!down) return;
    if (this.seedFocus) {
      if (/^\d$/.test(e.key) && this.seedText.length < 10) { this.seedText = this.seedText === '0' ? e.key : this.seedText + e.key; this.build(); }
      else if (e.code === 'Backspace') { this.seedText = this.seedText.slice(0, -1); this.build(); }
      else if (e.code === 'Enter' || e.code === 'Escape') this.commitSeed();
      return;
    }
    if (e.code === 'Enter') this.start();
    if (e.code === 'KeyM') { this.ctx.audio.toggleMute(); this.build(); }
  }
}
