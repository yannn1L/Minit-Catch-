import { Container } from 'pixi.js';
import type { GameContext } from '../../app/GameContext.ts';
import { FixedLoop } from '../../core/FixedLoop.ts';
import { UI } from '../../data/palette.ts';
import { TICK } from '../../domain/rules/constants.ts';
import type { MatchConfig, MatchResult, SimEvent } from '../../shared/types.ts';
import { Simulation, type SimView } from '../../sim/Simulation.ts';
import { DirectorCamera, OverviewCamera, type CameraState } from '../render/DirectorCamera.ts';
import { bindAudio, bindVfx } from '../render/EventBindings.ts';
import { PPM } from '../render/ArenaRenderer.ts';
import { WorldRenderer } from '../render/WorldRenderer.ts';
import { HudView } from '../ui/HudView.ts';
import { ResultOverlay } from '../ui/ResultOverlay.ts';
import { virtualFor } from '../ui/layout.ts';
import { EditorScene } from './EditorScene.ts';
import type { Scene } from './Scene.ts';

type Phase = 'countdown' | 'active' | 'results';
const SPEEDS = [0.5, 1, 2, 4] as const;
const COUNTDOWN_SEC = 3;

export class SimulationScene implements Scene {
  readonly root = new Container();
  private readonly ctx: GameContext;
  private readonly config: MatchConfig;
  private readonly expectedHash: string | null;
  private readonly isReplay: boolean;
  private sim!: Simulation;
  private renderer!: WorldRenderer;
  private hud!: HudView;
  private overlay!: ResultOverlay;
  private readonly ui = new Container();
  private readonly loop = new FixedLoop(TICK);
  private readonly director = new DirectorCamera();
  private readonly overview = new OverviewCamera();
  private readonly cam: CameraState = { x: 0, y: 0, zoom: 0 };
  private readonly keys = new Set<string>();
  private readonly unsubs: (() => void)[] = [];
  private phase: Phase = 'countdown';
  private countdown = COUNTDOWN_SEC;
  private lastCount = COUNTDOWN_SEC + 1;
  private speedIdx: number;
  private directorOn: boolean;
  private paused = false;
  private result: MatchResult | null = null;
  private resultsT = 0;
  private clock = 0;
  private alpha = 1;
  private w = 1;
  private h = 1;
  private baseZoom = 1;
  private leader = -1;
  private names: string[] = [];

  /** `expectedHash` is set when replaying a finished match: the re-simulation must reproduce the same event-log hash. */
  constructor(ctx: GameContext, config: MatchConfig, expectedHash: string | null = null, isReplay = false) {
    this.ctx = ctx;
    this.config = config;
    this.expectedHash = expectedHash;
    this.isReplay = isReplay;
    const idx = SPEEDS.indexOf(config.observer.speed as (typeof SPEEDS)[number]);
    this.speedIdx = idx >= 0 ? idx : 1;
    this.directorOn = config.observer.cameraDirector;
  }

  enter(): void {
    const { regs, sprites, font, audio } = this.ctx;
    this.sim = new Simulation(this.config, regs);
    const view: SimView = this.sim.view;
    const defs = this.sim.roasters.map((r) => regs.roasters.get(r.roasterId));
    this.names = defs.map((d) => d.name);
    this.renderer = new WorldRenderer(sprites, font, view, defs);
    this.hud = new HudView(font, view, defs, this.sim.abilities);
    this.overlay = new ResultOverlay(font);
    this.ui.addChild(this.hud.root, this.overlay.root);
    this.root.addChild(this.renderer.world, this.ui);

    const where = (slot: number): { x: number; y: number } => {
      const r = this.sim.roasters[slot]!;
      return { x: r.x, y: r.y };
    };
    this.unsubs.push(
      this.sim.events.bus.on((ev) => {
        bindAudio(ev, audio);
        bindVfx(ev, this.renderer.vfx, sprites, where);
        this.banner(ev);
      }),
    );
    this.sim.events.flush(); // deliver tick-0 spawn events to subscribers before the countdown
    audio.setDucked(true);
    audio.startBgm();
    this.cam.zoom = 0;
    this.resize(this.w, this.h);
    this.hud.setClock(this.config.durationSec);
    if (this.isReplay) this.hud.setStatus('REPLAY', UI.accent);
  }

  exit(): void {
    for (const u of this.unsubs) u();
    this.ctx.audio.setDucked(false);
  }

  private banner(ev: SimEvent): void {
    const n = (i: number): string => (this.names[i] ?? '?').toUpperCase();
    switch (ev.t) {
      case 'bomb': if (ev.hits > 0) this.hud.pushBanner(`${n(ev.owner)} STUNNED ${ev.hits} ROASTER${ev.hits > 1 ? 'S' : ''}!`); break;
      case 'lock': this.hud.pushBanner(`${n(ev.by)} LOCKED COOP ${ev.coop + 1}!`); break;
      case 'overtime': this.hud.pushBanner('OVERTIME! NEXT SCORE WINS'); break;
      case 'lure': this.hud.pushBanner(`${n(ev.owner)} DROPPED A DECOY!`); break;
      case 'ability':
        if (ev.hits > 0 && ev.ability === 'netter') this.hud.pushBanner(`${n(ev.roaster)} NETTED ${ev.hits}!`);
        else if (ev.hits > 0 && ev.ability === 'heavy') this.hud.pushBanner(`${n(ev.roaster)} SLAMMED ${ev.hits}!`);
        else if (ev.hits > 0 && ev.ability === 'magnetizer') this.hud.pushBanner(`${n(ev.roaster)} PULLED ${ev.hits} CHICKENS!`);
        break;
      case 'deliver': {
        let best = -1;
        let top = 0;
        let tie = false;
        for (const c of this.sim.coops) { if (c.score > top) { top = c.score; best = c.slot; tie = false; } else if (c.score === top) tie = true; }
        const lead = tie ? -1 : best;
        if (lead >= 0 && lead !== this.leader && top > 1) this.hud.pushBanner(`${n(lead)} TAKES THE LEAD!`);
        this.leader = lead;
        break;
      }
      default: break;
    }
  }

  resize(w: number, h: number): void {
    this.w = w;
    this.h = h;
    if (this.hud === undefined) return;
    const r = this.sim.arena.radius;
    this.baseZoom = Math.max(1, Math.floor((Math.min(w, h) * 0.94) / (2 * r * PPM)));
    const v = virtualFor(w, h);
    this.ui.scale.set(v.scale);
    this.ui.position.set(v.ox, v.oy);
    this.hud.layout(v.w, v.h);
    if (this.result !== null && this.phase === 'results' && this.resultsT > 1) this.showOverlay();
  }

  private showOverlay(): void {
    const v = virtualFor(this.w, this.h);
    let note = '';
    if (this.expectedHash !== null && this.result !== null) note = this.result.eventHash === this.expectedHash ? 'REPLAY OK: IDENTICAL LOG' : 'REPLAY MISMATCH!';
    this.overlay.show(this.result!, this.names, v.w, v.h, note);
  }

  onKey(e: KeyboardEvent, down: boolean): void {
    if (!down) { this.keys.delete(e.code); return; }
    this.keys.add(e.code);
    if (e.repeat) return;
    switch (e.code) {
      case 'Space': if (this.phase !== 'results') this.paused = !this.paused; break;
      case 'Digit1': case 'Digit2': case 'Digit3': case 'Digit4': this.speedIdx = Number(e.code.slice(5)) - 1; break;
      case 'KeyC': this.directorOn = !this.directorOn; break;
      case 'KeyM': this.ctx.audio.toggleMute(); break;
      case 'KeyR': this.ctx.scenes.goto(new SimulationScene(this.ctx, this.config, this.result?.eventHash ?? null, true)); break;
      case 'Escape': this.ctx.scenes.goto(new EditorScene(this.ctx)); break;
      case 'Equal': case 'NumpadAdd': if (!this.directorOn) this.cam.zoom = Math.min(8, this.cam.zoom + 1); break;
      case 'Minus': case 'NumpadSubtract': if (!this.directorOn) this.cam.zoom = Math.max(1, this.cam.zoom - 1); break;
      default: break;
    }
  }

  update(dt: number): void {
    this.clock += dt;
    const view = this.sim.view;
    if (this.phase === 'countdown') {
      if (!this.paused) this.countdown -= dt;
      const c = Math.ceil(this.countdown);
      if (c !== this.lastCount) {
        this.lastCount = c;
        if (c > 0) { this.ctx.audio.play('countdown'); this.hud.setCenter(String(c), 4, UI.accent); } else { this.ctx.audio.play('go'); this.hud.setCenter('GO!', 4, UI.good); }
      }
      if (this.countdown <= -0.5) { this.hud.setCenter(''); this.phase = 'active'; this.loop.reset(); } else if (this.countdown <= 0) this.hud.setCenter('GO!', 4, UI.good);
      this.alpha = 1;
    } else if (this.phase === 'active') {
      if (!this.paused) {
        this.alpha = this.loop.advance(dt * SPEEDS[this.speedIdx]!, () => this.sim.step());
        if (this.sim.ended) {
          this.phase = 'results';
          this.result = this.sim.result();
          this.resultsT = 0;
          this.alpha = 1;
        }
      }
      this.hud.setClock(view.phase === 'overtime' ? this.sim.overtimeEndTick * TICK - view.time : this.config.durationSec - view.time);
    } else {
      this.resultsT += dt;
      if (this.resultsT > 1 && !this.overlay.root.visible) this.showOverlay();
    }

    this.hud.setStatus(`${this.paused ? 'PAUSED ' : ''}${SPEEDS[this.speedIdx]}X ${this.directorOn ? 'DIRECTOR' : 'FREE'}${this.isReplay ? ' REPLAY' : ''}`, this.paused ? UI.accent : UI.dim);
    this.updateCamera(view, dt);
    this.renderer.vfx.update(this.paused ? 0 : dt * SPEEDS[this.speedIdx]!);
    this.renderer.render(view, this.alpha, this.clock);
    this.hud.update(dt, view);
  }

  private updateCamera(view: SimView, dt: number): void {
    if (this.phase === 'results') this.overview.update(view, dt, this.cam, this.baseZoom);
    else if (this.directorOn) this.director.update(view, dt, this.cam, this.baseZoom);
    else {
      if (this.cam.zoom < 1) this.cam.zoom = this.baseZoom;
      const sp = (14 * dt) / this.cam.zoom * 2;
      const k = this.keys;
      if (k.has('ArrowLeft') || k.has('KeyA')) this.cam.x -= sp;
      if (k.has('ArrowRight') || k.has('KeyD')) this.cam.x += sp;
      if (k.has('ArrowUp') || k.has('KeyW')) this.cam.y -= sp;
      if (k.has('ArrowDown') || k.has('KeyS')) this.cam.y += sp;
      const lim = view.arena.radius;
      this.cam.x = Math.max(-lim, Math.min(lim, this.cam.x));
      this.cam.y = Math.max(-lim, Math.min(lim, this.cam.y));
    }
    const z = Math.max(1, this.cam.zoom);
    const world = this.renderer.world;
    world.scale.set(z); // integer zoom + integer offset => pixel-perfect
    world.position.set(Math.round(this.w / 2 - this.cam.x * PPM * z), Math.round(this.h / 2 - this.cam.y * PPM * z));
  }
}
